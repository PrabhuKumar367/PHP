<?php
include 'connect.php';
class login extends connect
{
    public function __construct()
    {
      parent::__construct();
    }
  public function login()
	{
		    if($this->db_found)
            {
                               $f=0;
				               $r=mysqli_query($this->db_found,"select* from login;");			                
								while	($db_field=mysqli_fetch_assoc($r))
								{
								     if($db_field['logid']==$_POST['t1'])
                                     {
                                        if($db_field['logpwd']==$_POST['t2'])
                                        {
                                            $f=1;
                                            break;
                                        }
                                     }
                                }
                                if($f==1)
                                 echo"<script>window.open('home.html','_self')</script>";
                                else
                                 echo "<script>alert('This is wrong or password')</script>";

								
			}
            else
              echo "Database not found";
    }
  
}

$ob=new login();
if(isset($_REQUEST["b1"]))
	$ob->login();
?>