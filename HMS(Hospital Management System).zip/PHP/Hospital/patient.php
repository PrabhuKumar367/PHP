<?php
include 'connect.php';
class patient extends connect
{
  public function __construct()
  {
    parent::__construct();
  }
  public function Save()
  {
     if($this->db_found==true)
	  {	   
		$f=0;
		$r=mysqli_query($this->db_found,"select* from patient");			                
		 while	($db_field=mysqli_fetch_assoc($r))
		 {
			  if($db_field['patient_id']==$_POST['t1'])
			  { 
					 $f=1;
					 break;	 
			  }
		 }
		if($f==1)
		  echo "<script>alert('Hospital ID already exist')</script>";
		else
		{
			$sql="insert into patient values('$_POST[t1]','$_POST[t2]','$_POST[t3]','$_POST[t4]','$_POST[t5]','$_POST[t6]','$_POST[t7]')";
			mysqli_query($this->db_found,$sql);
			echo "<script> alert('Record Saved')</script>";
	    }			  	          
      }
     else
        echo "<script> alert ('Database Not Found')</script>";
 }

  public function Delete()
  {
     if($this->db_found==true)
     {
      $sql="delete from patient where(patient_id='$_POST[t1]')";
       mysqli_query($this->db_found,$sql);
       echo "<script> alert('Record Deleted')</script>";
      }
     else
        echo "<script> alert ('Database Not Found')</script>";
    }

    public function update()
	{
		if($this->db_found)
			{
				$sql="update patient set patient_name='$_POST[t2]',gender='$_POST[t3]',nationality='$_POST[t4]',birth_date='$_POST[t5]',contact='$_POST[t6]',blood_group='$_POST[t7]' where patient_id='$_POST[t1]'";
				mysqli_query($this->db_found,$sql);
				echo"<script>alert('Record updated...')</script>";
			}
		else
			    echo"<script>alert('database not found....')</script>";
	}


  public function allsearch()
	{
		if($this->db_found)
			{
				$r=mysqli_query($this->db_found,"select* from patient order by patient_id;");
				                echo"<center>";
								echo"<bdoy><h1><u> Pattent Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Patient ID</th>
									<th>Patient name</th>
									<th>Gender</th>
									<th>Nationality</th>
									<th>Date of Birth</th>
                  <th>Contact</th>
									<th>Blood Group</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['patient_id']."</td>";
										echo"<td>"
													.$db_field['patient_name']."</td>";
										echo"<td>"
													.$db_field['gender']."</td>";
										echo"<td>"
													.$db_field['nationality']."</td>";
										echo"<td>"
													.$db_field['birth_date']."</td>";
                    echo"<td>"
													.$db_field['contact']."</td>";
										echo"<td>"
													.$db_field['blood_group']."</td>";
                                        echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
	}

  public function psearch()
	{
		if($this->db_found)
			{
				$id=$_POST["t1"];
				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,"select * from patient where patient_id='$id';");
				        echo"<center>";
								echo"<bdoy><h1><u> Pattent Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Patient ID</th>
									<th>Patient name</th>
									<th>Gender</th>
									<th>Nationality</th>
									<th>Date of Birth</th>
                  <th>Contact</th>
									<th>Blood Group</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['patient_id']."</td>";
										echo"<td>"
													.$db_field['patient_name']."</td>";
										echo"<td>"
													.$db_field['gender']."</td>";
										echo"<td>"
													.$db_field['nationality']."</td>";
										echo"<td>"
													.$db_field['birth_date']."</td>";
                    echo"<td>"
													.$db_field['contact']."</td>";
										echo"<td>"
													.$db_field['blood_group']."</td>";
                                        echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
	}


	public function specialsearch()
	{
		if($this->db_found)
			{
				$id=$_POST["t1"];
				$col=$_POST["s1"];
                   if($col=="all")
                    $s="select * from patient";
				else
				    $s="select * from patient where  $col='$id';";

				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,$s);
				        echo"<center>";
								echo"<bdoy><h1><u> Pattent Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Patient ID</th>
									<th>Patient name</th>
									<th>Gender</th>
									<th>Nationality</th>
									<th>Date of Birth</th>
                  <th>Contact</th>
									<th>Blood Group</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['patient_id']."</td>";
										echo"<td>"
													.$db_field['patient_name']."</td>";
										echo"<td>"
													.$db_field['gender']."</td>";
										echo"<td>"
													.$db_field['nationality']."</td>";
										echo"<td>"
													.$db_field['birth_date']."</td>";
                    echo"<td>"
													.$db_field['contact']."</td>";
										echo"<td>"
													.$db_field['blood_group']."</td>";
                                        echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
	}


	public function specialupdate()
    {
      if($this->db_found==true)
      {
        $f=$_POST['t1'];
        $s=$_POST['s1'];
        $m="select * from  patient where $s='$f'";
        $r=mysqli_query($this->db_found,$m);
        echo "<table border=2 bgcolor=pink><tr><th>Patient id</th><th>Patient name</th><th>Gender</th><th>Nationality</th><th>Birth date</th><th>Conatct no</th><th>Blood group</th></tr>"; 
        while($db_field=mysqli_fetch_assoc($r))
        {
          echo "<form name=f method=post action=patient.php>";
          echo "<tr><th><input type=text value=".$db_field['patient_id']."  name=t1 readonly></th>";
          echo "<th><input type=text value=".$db_field['patient_name']." name=t2></th>";
          echo "<th><input type=text value=".$db_field['gender']." name=t3></th>";
          echo "<th><input type=text value=".$db_field['nationality']." name=t4></th>";
          echo "<th><input type=text value=".$db_field['birth_date']." name=t5></th>";
          echo "<th><input type=text value=".$db_field['contact_no']." name=t6></th>";
          echo "<th><input type=text value=".$db_field['blood_group']." name=t7></th>";
          echo "<th><input type=submit value=Update name=b4></th></tr>";
        }
      }
    }
}

$ob=new patient();
if(isset($_REQUEST["b1"]))
	$ob->save();
if(isset($_REQUEST["b2"]))
	$ob->update();
if(isset($_REQUEST["b3"]))
	$ob->delete();
if(isset($_REQUEST["b4"]))
	$ob->allsearch();
if(isset($_REQUEST["b5"]))
	$ob->psearch();
if(isset($_REQUEST["bpupdate"]))
	$ob->specialupdate();

if(isset($_REQUEST["bpsearch"]))
	$ob->specialsearch();
?>