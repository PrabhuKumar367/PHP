<?php
include 'connect.php';
class treatment extends connect
{
  public function __construct()
  {
    parent::__construct();
  }
  public function Save()
  {
     if($this->db_found==true)
      { 
        $f=0;
        $r=mysqli_query($this->db_found,"select* from treatment");			                
         while	($db_field=mysqli_fetch_assoc($r))
         {
            if($db_field['treatment_id']==$_POST['t1'])
            { 
               $f=1;
               break;	 
            }
         }

         $r=mysqli_query($this->db_found,"select* from treatment");
         $h=0;
         while	($db_field=mysqli_fetch_assoc($r))
         {
            if($db_field["appointment_id"]==$_POST["t2"])
            { 
             $h=1;//hospital id match
             break;
            }
         }
        if($f==0 && $h==1)
        {
          $sql="insert into treatment values('$_POST[t1]','$_POST[t2]','$_POST[t3]')";
          mysqli_query($this->db_found,$sql);
          echo "<script> alert('Record Saved')</script>";
         } 
        else if($f==1)
         echo"<script> alert ('Tratment id already exist') </script>";
        else if($h==0)
         echo"<script> alert ('appointment id not present') </script>";
         }
     else
        echo "<script> alert ('Database Not Found')</script>";
    }

  public function Delete()
  {
     if($this->db_found==true)
     {
       $sql="delete from treatment where(treatment_id='$_POST[t1]')";
       mysqli_query($this->db_found,$sql);
       echo "<script> alert('Record Deleted')</script>";
      }
     else
        echo "<script> alert ('Database Not Found')</script>";
  }


  public function update()
	{
		if($this->db_found)
			{
				$sql="update treatment set appointment_id='$_POST[t2]',remarks='$_POST[t3]' where treatment_id='$_POST[t1]'";
				mysqli_query($this->db_found,$sql);
				echo"<script>alert('Record update...')</script>";
			}
		else
			    echo"<script>alert('database not found....')</script>";
	}

  public function allsearch()
    {
      if($this->db_found)
        {
          $r=mysqli_query($this->db_found,"select* from treatment order by treatment_id;");
                          echo"<center>";
                  echo"<bdoy><h1><u> Treatment Detail </u></h1>";
                  echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
                  echo"<tr bgcolor=cray>";
                  echo"<th>Treatement ID</th>
                    <th>Appointment Id</th>
                    <th>Remarks</th>";
                  echo"</tr>";
                  while	($db_field=mysqli_fetch_assoc($r))
                    {
                          echo"<tr>";
                      echo"<td>"
                            .$db_field['treatment_id']."</td>";
                      echo"<td>"
                            .$db_field['appointment_id']."</td>";
                      echo"<td>"
                            .$db_field['remarks']."</td>";
                     echo"</tr>";
                    }
                  echo"</table>";
                  echo"</center>";
        }
    }
  
    public function psearch()
    {
      if($this->db_found)
        {
          $id=$_POST["t1"];
				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,"select * from treatment where  treatment_id='$id';");
                          echo"<center>";
                  echo"<bdoy><h1><u> Treatment Detail </u></h1>";
                  echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
                  echo"<tr bgcolor=cray>";
                  echo"<th>Treatement ID</th>
                    <th>Appointment Id</th>
                    <th>Remarks</th>";
                  echo"</tr>";
                  while	($db_field=mysqli_fetch_assoc($r))
                    {
                          echo"<tr>";
                      echo"<td>"
                            .$db_field['treatment_id']."</td>";
                      echo"<td>"
                            .$db_field['appointment_id']."</td>";
                      echo"<td>"
                            .$db_field['remarks']."</td>";
                     echo"</tr>";
                    }
                  echo"</table>";
                  echo"</center>";
        }
    }

    public function specialsearch()
    {
      if($this->db_found)
        {
          $id=$_POST["t1"];
				$col=$_POST["s1"];
                   if($col=="all")
                    $s="select * from treatment";
				else
				    $s="select * from treatment where  $col='$id';";

				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,$s);
                  echo"<center>";
                  echo"<bdoy><h1><u> Treatment Detail </u></h1>";
                  echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
                  echo"<tr bgcolor=cray>";
                  echo"<th>Treatement ID</th>
                    <th>Appointment Id</th>
                    <th>Remarks</th>";
                  echo"</tr>";
                  while	($db_field=mysqli_fetch_assoc($r))
                    {
                          echo"<tr>";
                      echo"<td>"
                            .$db_field['treatment_id']."</td>";
                      echo"<td>"
                            .$db_field['appointment_id']."</td>";
                      echo"<td>"
                            .$db_field['remarks']."</td>";
                     echo"</tr>";
                    }
                  echo"</table>";
                  echo"</center>";
        }
    }

    
}

$ob=new treatment();
if(isset($_REQUEST["b1"]))
  $ob->Save();
if(isset($_REQUEST["b2"]))
	$ob->update();
if(isset($_REQUEST["b3"]))
  $ob->Delete();
if(isset($_REQUEST["b4"]))
	$ob->allsearch();
if(isset($_REQUEST["b5"]))
	$ob->psearch();
if(isset($_REQUEST["bpsearch"]))
	$ob->specialsearch();
?>