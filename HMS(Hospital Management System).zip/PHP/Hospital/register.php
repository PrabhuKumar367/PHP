<?php
include 'connect.php';
class register extends connect
{
    public function __construct()
    {
      parent::__construct();
    }
  public function register()
	{
		    if($this->db_found)
            {
                               $f=0;
				               $r=mysqli_query($this->db_found,"select* from login;");			                
								while	($db_field=mysqli_fetch_assoc($r))
								{
								     if($db_field['logid']==$_POST['t1'])
                                     {
                                        if($db_field['logpwd']==$_POST['t2'])
                                        {
                                            $f=1;
                                            break;
                                        }
                                     }
                                }
                                if($f==1)
                                 echo"<script>window.open('home.html','_self')</script>";
                                else
                                 echo "<script>alert('This is wrong or password')</script>";					
			}
            else
              echo "Database not found";
    }
  
}

$ob=new register();
if(isset($_REQUEST["b1"]))
	$ob->register();
?>