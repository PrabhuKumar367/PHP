-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 12, 2024 at 06:44 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appointment_id` varchar(10) DEFAULT NULL,
  `hospital_id` varchar(10) DEFAULT NULL,
  `appointment_date` varchar(10) DEFAULT NULL,
  `appointment_time` varchar(10) DEFAULT NULL,
  `doctor_id` varchar(10) DEFAULT NULL,
  `service_id` varchar(10) DEFAULT NULL,
  `patient_id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appointment_id`, `hospital_id`, `appointment_date`, `appointment_time`, `doctor_id`, `service_id`, `patient_id`) VALUES
('a001', 'h001', '2024-08-01', '21:57', 'd001', 's007', 'p001'),
('a002', 'yyy', '2024-08-08', '07:49', 'dddd', 'sssss', 'pppp'),
('a003', 'C001', '2024-08-08', '21:29', 'C001', 'C001', 'C001');

-- --------------------------------------------------------

--
-- Table structure for table `bookappoint`
--

CREATE TABLE `bookappoint` (
  `name` varchar(15) DEFAULT NULL,
  `email` varchar(15) DEFAULT NULL,
  `mobile` int(11) DEFAULT NULL,
  `c_doctor` varchar(15) DEFAULT NULL,
  `date` varchar(15) DEFAULT NULL,
  `time` varchar(10) DEFAULT NULL,
  `desc_prop` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookappoint`
--

INSERT INTO `bookappoint` (`name`, `email`, `mobile`, `c_doctor`, `date`, `time`, `desc_prop`) VALUES
('', '', 0, 'Choose Doctor', '', '', ''),
('Priyam kumar', 'kpriyam840@gmai', 2147483647, '1', '09/02/2024', '11:41 PM', 'how hello'),
('', '', 0, 'Choose Doctor', '', '', ''),
('', '', 0, 'Choose Doctor', '', '', ''),
('ali', 'abhishekkumar23', 2147483647, '1', '09/12/2024', '5:39 PM', ''),
('abhishek kumar', 'abhishekkumar23', 2147483647, '1', '09/15/2024', '7:55 PM', 'uyfyufyufu');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `name` varchar(15) DEFAULT NULL,
  `mail` varchar(20) DEFAULT NULL,
  `subject` varchar(15) DEFAULT NULL,
  `message` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`name`, `mail`, `subject`, `message`) VALUES
('', '', '', ''),
('priyam', 'kpriyam840@gmail.com', 'hhhhh', 'how are you'),
('sumit', 'abhishekkumar2300@gm', 'mca', 'how are you priyam'),
('kundan ', 'kundan840@gmail.com', 'emergency', 'discount fee'),
('', '', '', ''),
('dhanjee', 'abhishekkumar2800@gm', 'enq', 'how are you'),
('', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doctor_id` varchar(10) DEFAULT NULL,
  `doctor_name` varchar(10) DEFAULT NULL,
  `contact_no` int(11) DEFAULT NULL,
  `e_mail` varchar(20) DEFAULT NULL,
  `specialization` varchar(10) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `hospital_id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doctor_id`, `doctor_name`, `contact_no`, `e_mail`, `specialization`, `gender`, `hospital_id`) VALUES
('d00112', 'pkkk', 2147483647, 'kpriyam840@gmail.com', 'dddd', 'Male', 'h001'),
('C001', 'monu', 4587, 'jhuy32@gmail.com', '', 'Female', ''),
('d001', 'kamla', 954648, 'kpriyam840@gmail.com', 'mca', 'Female', 'C001'),
('C008', '', 0, '', '', 'Female', 'C005'),
('C0012', '', 0, '', '', 'Female', 'C001');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_schedule`
--

CREATE TABLE `doctor_schedule` (
  `doctor_id` varchar(10) DEFAULT NULL,
  `start_date` varchar(10) DEFAULT NULL,
  `end_date` varchar(15) DEFAULT NULL,
  `start_time` varchar(10) DEFAULT NULL,
  `end_time` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor_schedule`
--

INSERT INTO `doctor_schedule` (`doctor_id`, `start_date`, `end_date`, `start_time`, `end_time`) VALUES
('C001', '2024-08-5', '2024-08-25', '17:38', '20:28');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `hospital_id` varchar(10) DEFAULT NULL,
  `hospital_name` varchar(10) DEFAULT NULL,
  `contact_no` int(11) DEFAULT NULL,
  `e_mail` varchar(15) DEFAULT NULL,
  `contact_person` varchar(10) DEFAULT NULL,
  `region` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hospital_id`, `hospital_name`, `contact_no`, `e_mail`, `contact_person`, `region`) VALUES
('C001', 'kamla', 2147483647, 'k23@gmail.com', 'eeee', 'pool'),
('', '', 0, '', '', ''),
('C002', 'jhuih', 758, 'iuy443@gmail.co', 'gui', 'hhh'),
('C005', 'uigyu', 7888888, 'kpriyam840@gmai', 'eeee', 'R001');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `logid` varchar(10) DEFAULT NULL,
  `logpwd` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`logid`, `logpwd`) VALUES
('hospital', 'hospital');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `medicine_id` varchar(20) NOT NULL,
  `medicine_name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`medicine_id`, `medicine_name`) VALUES
('', ''),
('c005', 'sonali'),
('C0078', 'inventory'),
('m009', 'aldegestic'),
('m008', 'paracetamo');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patient_id` varchar(10) DEFAULT NULL,
  `patient_name` varchar(10) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `nationality` varchar(15) DEFAULT NULL,
  `birth_date` varchar(10) DEFAULT NULL,
  `contact_no` int(11) DEFAULT NULL,
  `blood_group` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patient_id`, `patient_name`, `gender`, `nationality`, `birth_date`, `contact_no`, `blood_group`) VALUES
('C001', 'sonali', 'male', 'mongo', '2028-05-05', 7256, 'o+'),
('C002', 'abhi', 'male', 'pakistan', '2024-09-14', 954648, 'A+'),
('C003', 'khushi', 'female', 'goaa', '2024-09-07', 809440, 'O+');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `name` varchar(15) DEFAULT NULL,
  `email` varchar(15) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `c_doctor` varchar(15) DEFAULT NULL,
  `date` varchar(10) DEFAULT NULL,
  `time` varchar(10) DEFAULT NULL,
  `desc_prop` varchar(18) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`name`, `email`, `number`, `c_doctor`, `date`, `time`, `desc_prop`) VALUES
('', '', 0, 'Choose Doctor', '', '', ''),
('Priyam kumar', 'kpriyam840@gmai', 2147483647, 'Dr.priyam panda', '09/09/2024', '12:30 AM', 'hello'),
('', '', 0, 'Choose Doctor', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` varchar(10) DEFAULT NULL,
  `service_name` varchar(20) DEFAULT NULL,
  `fee` int(11) DEFAULT NULL,
  `hospital_id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_name`, `fee`, `hospital_id`) VALUES
('C001', 'inventory', 10000000, 'h0012'),
('C002', 'inventory', 50000, 'h005');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` varchar(10) DEFAULT NULL,
  `staff_name` varchar(10) DEFAULT NULL,
  `designation` varchar(15) DEFAULT NULL,
  `contact_no` int(11) DEFAULT NULL,
  `e_mail` varchar(10) DEFAULT NULL,
  `hospital_id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `staff_name`, `designation`, `contact_no`, `e_mail`, `hospital_id`) VALUES
('C001', 'komal', 'zero', 954648, 'komal@123', 'H002'),
('C002', 'golu', 'patna', 48756, 'kiju321@gm', 'h005');

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE `treatment` (
  `treatment_id` varchar(10) DEFAULT NULL,
  `appointment_id` varchar(10) DEFAULT NULL,
  `remarks` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`treatment_id`, `appointment_id`, `remarks`) VALUES
('C001', 'a002', 'cut'),
('C002', 'a005', 'yjgyj');

-- --------------------------------------------------------

--
-- Table structure for table `treatment_details`
--

CREATE TABLE `treatment_details` (
  `treatment_id` varchar(10) DEFAULT NULL,
  `medicine_id` varchar(12) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `dosage_desc` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `treatment_details`
--

INSERT INTO `treatment_details` (`treatment_id`, `medicine_id`, `quantity`, `dosage_desc`) VALUES
('', '', 0, ''),
('C001', 'm008', 875, 'goodpol');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
