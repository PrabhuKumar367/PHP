<?php
include 'connect.php';
class service1 extends connect
{
  public function __construct()
  {
    parent::__construct();
  }
  public function Save()
  {
     if($this->db_found==true)
	  {   
	   	$f=0;
		$r=mysqli_query($this->db_found,"select* from services");			                
		 while	($db_field=mysqli_fetch_assoc($r))
		 {
			  if($db_field['service_id']==$_POST['t1'])
			  { 
					 $f=1;
					 break;	 
			  }
		 }
		 $r=mysqli_query($this->db_found,"select* from services");
		 $h=0;

		 while	($db_field=mysqli_fetch_assoc($r))
		 {
			  if($db_field["hospital_id"]==$_POST["t4"])
			  { 
				 $h=1;//hospital id match
				 break;
			  }
		 }

		 if($f==0 && $h==1)
		 {
			$sql="insert into services values('$_POST[t1]','$_POST[t2]','$_POST[t3]','$_POST[t4]')";
			mysqli_query($this->db_found,$sql);
			echo "<script> alert('Service All Record Saved')</script>";
		 } 
		 else if($f==1)
			echo"<script> alert ('Service id already exist') </script>";
		 else if($h==0)
			echo"<script> alert ('Hospital id not present') </script>";
      }  
    
    else
        echo "<script> alert ('Database Not Found')</script>";
  }

  public function Delete()
  {
     if($this->db_found==true)
     {
       $sql="delete from services where(service_id='$_POST[t1]')";
       mysqli_query($this->db_found,$sql);
       echo "<script> alert('Record Deleted')</script>";
      }
     else
        echo "<script> alert ('Database Not Found')</script>";
  }

  public function update()
	{
		if($this->db_found)
			{
				$sql="update services set service_name='$_POST[t2]',fee='$_POST[t3]',hospital_id='$_POST[t4]' where service_id='$_POST[t1]'";
				mysqli_query($this->db_found,$sql);
				echo"<script>alert('Record update...')</script>";
			}
		else
			    echo"<script>alert('database not found....')</script>";
	}

  public function allsearch()
	{
		if($this->db_found)
			{
				$r=mysqli_query($this->db_found,"select* from services order by service_id;");
				        echo"<center>";
								echo"<bdoy><h1><u> Service Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Service ID</th>
									<th>Service Name</th>
									<th>Fee</th>
									<th>Hospital id</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['service_id']."</td>";
										echo"<td>"
													.$db_field['service_name']."</td>";
										echo"<td>"
													.$db_field['fee']."</td>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";
                                        echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
	}

  public function psearch()
	{
		if($this->db_found)
			{
				$id=$_POST["t1"];
				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,"select * from services where  service_id='$id';");
				        echo"<center>";
								echo"<bdoy><h1><u> Service Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Service ID</th>
									<th>Service Name</th>
									<th>Fee</th>
									<th>Hospital id</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['service_id']."</td>";
										echo"<td>"
													.$db_field['service_name']."</td>";
										echo"<td>"
													.$db_field['fee']."</td>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";
                    echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
  }


  public function specialsearch()
	{
		if($this->db_found)
			{
				$id=$_POST["t1"];
				$col=$_POST["s1"];
                   if($col=="all")
                    $s="select * from services";
				else
				    $s="select * from services where  $col='$id';";

				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,$s);
				        echo"<center>";
								echo"<bdoy><h1><u> Service Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Service ID</th>
									<th>Service Name</th>
									<th>Fee</th>
									<th>Hospital id</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['service_id']."</td>";
										echo"<td>"
													.$db_field['service_name']."</td>";
										echo"<td>"
													.$db_field['fee']."</td>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";
                    echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
  }
}

$ob=new service1();
if(isset($_REQUEST["b1"])) 
  $ob->Save();
if(isset($_REQUEST["b2"]))
	$ob->update();
if(isset($_REQUEST["b3"]))
  $ob->Delete();
if(isset($_REQUEST["b4"]))
	$ob->allsearch();
if(isset($_REQUEST["b5"]))
	$ob->psearch();
if(isset($_REQUEST["bpsearch"]))
	$ob->specialsearch();
?>