<?php
include 'connect.php';
class doctor extends connect
{
	public function __construct()
	{
		parent::__construct();
	}
	public function save()
	{
		if($this -> db_found ==true)
		{
			$r=mysqli_query($this->db_found,"select* from doctor");
			$f=0;
			while	($db_field=mysqli_fetch_assoc($r))
			{
				if($db_field["doctor_id"]==$_POST["t1"])
				{ 
					$f=1; //doctor id exist
					break;
				}
			}
		
		
			$r=mysqli_query($this->db_found,"select* from hospital");
			$h=0;
			while	($db_field=mysqli_fetch_assoc($r))
			{
				 if($db_field["hospital_id"]==$_POST["t6"])
				 { 
					$h=1;//hospital id match
					break;
				 }
			}
			
			if($f==0 && $h==1)
			{
				$sql = "insert into doctor values ('$_POST[t1]','$_POST[t2]','$_POST[t3]','$_POST[t4]','$_POST[t5]','$_POST[t6]')";
				mysqli_query($this -> db_found, $sql);
				echo"<script> alert ('Record Save') </script>";
			}
			else if($f==1)
				echo"<script> alert ('Doctor id already exist') </script>";
			else if($h==0)
				 echo"<script> alert ('Hospital id not present') </script>";
		}
		else
			echo"<script> alert ('Database Not Found') </script>";
	}
	public function delete()
	{
		if($this->db_found==true)
			{
				$sql="delete from  doctor where doctor_id='$_POST[t1]'";
				mysqli_query($this->db_found,$sql);
				echo"<script>alert('Record deleted...')</script>";
			}
		else
			    echo"<script>alert('database not found....')</script>";
	}

	public function update()
	{
		if($this->db_found)
			{
				$sql="update doctor set contact_no='$_POST[t2]',e_mail='$_POST[t3]',specialization='$_POST[t4]',gender='$_POST[t5]',hospital_id='$_POST[t6]' where doctor_id='$_POST[t1]'";
				mysqli_query($this->db_found,$sql);
				echo"<script>alert('Record update...')</script>";
			}
		else
			    echo"<script>alert('database not found....')</script>";
	}

	public function allsearch()
	{
		if($this->db_found)
			{
				$r=mysqli_query($this->db_found,"select* from doctor order by doctor_id;");
				                echo"<center>";
								echo"<body><h1><u> All Doctor Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Doctor ID</th>
									<th>Contact Number</th>
									<th>Email</th>
									<th>Specialization</th>
									<th>Gender</th>
									<th>Hospital id</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['doctor_id']."</td>";
										echo"<td>"
													.$db_field['contact_number']."</td>";
										echo"<td>"
													.$db_field['e_mail']."</td>";
										echo"<td>"
													.$db_field['specialization']."</td>";
										echo"<td>"
													.$db_field['gender']."</td>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";
                                        echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
	}
				
	public function psearch()
	{
		if($this->db_found)
			{
				$id=$_POST["t1"];
				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,"select * from doctor where  doctor_id='$id';");
				                echo"<center>";
								echo"<body><h1><u> Particular Doctor Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>doctor ID</th>
									 <th>contact number</th>
									 <th>email</th>
									 <th>specialization</th>
									 <th>gender</th>
									<th>hospital id</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>" 
										            .$db_field['doctor_id']."</td>";				
										echo"<td>"
													.$db_field['contact_number']."</td>";
										echo"<td>"
													.$db_field['e_mail']."</td>";
										echo"<td>"
													.$db_field['specialization']."</td>";
										echo"<td>"
													.$db_field['gender']."</td>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";

										echo"</tr>";																
									}
								echo"</table>";
								echo"<center>";
			}
	}

    public function specialsearch()
	{
		if($this->db_found)
			{
				$id=$_POST["t1"];
				$col=$_POST["s1"];
                   if($col=="all")
                    $s="select * from doctor";
				else
				    $s="select * from doctor where  $col='$id';";

				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,$s);
				                echo"<center>";
								echo"<body><h1><u> Doctor Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>doctor ID</th>
									 <th>contact number</th>
									 <th>email</th>
									 <th>specialization</th>
									 <th>gender</th>
									<th>hospital id</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>" 
										            .$db_field['doctor_id']."</td>";				
										echo"<td>"
													.$db_field['contact_no']."</td>";
										echo"<td>"
													.$db_field['e_mail']."</td>";
										echo"<td>"
													.$db_field['specialization']."</td>";
										echo"<td>"
													.$db_field['gender']."</td>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";

										echo"</tr>";																
									}
								echo"</table>";
								echo"<center>";
			}
	}


	public function specialupdate()
    {
      if($this->db_found==true)
      {
        $f=$_POST['t1'];
        $s=$_POST['s1'];
        $m="select * from  doctor where $s='$f'";
        $r=mysqli_query($this->db_found,$m);
        echo "<table border=2 bgcolor=pink><tr><th>Doctor Id</th><th>Contact Number</th><th>Email</th><th>Specialization</th><th>Hospital Id</th><th>gender</th><th>hospital id</th></tr>"; 
        while($db_field=mysqli_fetch_assoc($r))
        {
          echo "<form name=f method=post action=doctor.php>";
          echo "<tr><th><input type=text value=".$db_field['doctor_id']."  name=t1 readonly></th>";
          echo "<th><input type=text value=".$db_field['contact_no']." name=t2></th>";
          echo "<th><input type=text value=".$db_field['e_mail']." name=t3></th>";
          echo "<th><input type=text value=".$db_field['specialization']." name=t4></th>";
          echo "<th><input type=text value=".$db_field['gender']." name=t5></th>";
          echo "<th><input type=text value=".$db_field['hospital_id']." name=t6 readonly></th>";
          echo "<th><input type=submit value=update name=b2></th></tr>";
        }
      }
    }
}
$ob=new doctor();
if(isset($_REQUEST["b1"]))
	$ob->save();
if(isset($_REQUEST["b2"]))
	$ob->update();
if(isset($_REQUEST["b3"]))
	$ob->delete();
if(isset($_REQUEST["b4"]))
	$ob->allsearch();
if(isset($_REQUEST["b5"]))
	$ob->psearch();
if(isset($_REQUEST["bpsearch"]))
	$ob->specialsearch();
if(isset($_REQUEST["bpupdate"]))
	$ob->specialupdate();
?>