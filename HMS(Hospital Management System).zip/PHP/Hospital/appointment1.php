

<?php
include 'connect.php';
class appointment1 extends connect
{
  public function __construct()
    {
       parent::__construct();
    }
  public function Save()
  {
     if($this->db_found==true)
	  {	   
	   
		$f=0;
		$r=mysqli_query($this->db_found,"select* from appointment");			                
		 while	($db_field=mysqli_fetch_assoc($r))
		 {
			  if($db_field['appointment_id']==$_POST['t1'])
			  { 
					 $f=1;
					 break;	 
			  }
		 } 
		 $r=mysqli_query($this->db_found,"select* from hospital");
		 $h=0;
		 while	($db_field=mysqli_fetch_assoc($r))
		 {
			  if($db_field["hospital_id"]==$_POST["t2"])
			  { 
				 $h=1;//hospital id match
				 break;
			  }
		 } 
		 $r=mysqli_query($this->db_found,"select * from doctor");
		 $d=0;
		 while	($db_field=mysqli_fetch_assoc($r))
		 {
			  if($db_field["doctor_id"]==$_POST["t5"])
			  { 
				 $d=1;//Doctror id match
				 break;
			  }
		 }
		 $r=mysqli_query($this->db_found,"select * from services");
		 $s=0;
		 while	($db_field=mysqli_fetch_assoc($r))
		 {
			  if($db_field["service_id"]==$_POST["t6"])
			  { 
				 $s=1;//service id match
				 break;
			  }
		 }
		 $r=mysqli_query($this->db_found,"select * from patient");
		 $p=0;
		 while	($db_field=mysqli_fetch_assoc($r))
		 {
			  if($db_field["patient_id"]==$_POST["t7"])
			  { 
				 $p=1;//service id match
				 break;
			  }
		 }
		 if($f==0 && $h==1 && $d==1 && $s==1 && $p==1) 
		 {
			$sql="insert into appointment values('$_POST[t1]','$_POST[t2]','$_POST[t3]','$_POST[t4]','$_POST[t5]','$_POST[t6]','$_POST[t7]')";
			mysqli_query($this->db_found,$sql);
			echo "<script> alert('Record Saved')</script>";
		}
		else if($f==1)
			echo"<script> alert ('Appointment id already exist') </script>"; 
		else if($h==0)
			echo"<script> alert ('Hospital id not present') </script>"; 
		else if($d==0)
			echo"<script> alert ('Doctor id not present') </script>";
		else if($s==0)
			echo"<script> alert ('Service id not present') </script>";
		else if($p==0)
			echo"<script> alert ('Patient id not present') </script>";
      }
	
     else
        echo "<script> alert ('Database Not Found')</script>";
    }

	
  public function Delete()
  {
     if($this->db_found==true)
     {
      $sql="delete from appointment where(appointment_id='$_POST[t1]')";
       mysqli_query($this->db_found,$sql);
       echo "<script> alert('Record Dleted')</script>";
      }
     else
        echo "<script> alert ('Database Not Found')</script>";
    }

    public function update()
	{
		if($this->db_found)
			{
				$sql="update appointment set hospital_id='$_POST[t2]',appointment_date='$_POST[t3]',appointment_time='$_POST[t4]',doctor_id='$_POST[t5]',service_id='$_POST[t6]',patient_id='$_POST[t7]' where appointment_id='$_POST[t1]'";
				mysqli_query($this->db_found,$sql);
				echo"<script>alert('Record update...')</script>";
			}
		else
			    echo"<script>alert('database not found....')</script>";
	}

  public function allsearch()
	{
		if($this->db_found)
			{
				$r=mysqli_query($this->db_found,"select* from appointment order by appointment_id");
				                echo"<center>";
								echo"<bdoy><h1><u> All appointment Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Appointment ID</th>
									<th>Hospital Id</th>
									<th>Appointment Date</th>
									<th>Appointment Time</th>
									<th>Doctor Id </th>
									<th>Service Id </th>
                 				    <th>Patient Id </th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['appointment_id']."</td>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";
										echo"<td>"
													.$db_field['appointment_date']."</td>";
										echo"<td>"
													.$db_field['appointment_time']."</td>";
										echo"<td>"
													.$db_field['doctor_id']."</td>";
										echo"<td>"
													.$db_field['service_id']."</td>";
                    echo"<td>"
													.$db_field['patient_id']."</td>";
                    echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
	}

  public function Psearch()
	{
		if($this->db_found)
			{
				$id=$_POST["t1"];
				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,"select * from appointment where  appointment_id='$id'");
				        echo"<center>";
								echo"<bdoy><h1><u> All appointment Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Appointment ID</th>
									<th>Hospital Id</th>
									<th>Appointment Date</th>
									<th>Appointment Time</th>
									<th>Doctor Id </th>
									<th>Service Id </th>
                  <th>Patient Id </th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['appointment_id']."</td>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";
										echo"<td>"
													.$db_field['appointment_date']."</td>";
										echo"<td>"
													.$db_field['appointment_time']."</td>";
										echo"<td>"
													.$db_field['doctor_id']."</td>";
										echo"<td>"
													.$db_field['service_id']."</td>";
                    echo"<td>"
													.$db_field['patient_id']."</td>";
                    echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
	}
  
	public function specialsearch()
	{
		if($this->db_found)
			{
				$id=$_POST["t1"];
				$col=$_POST["s1"];
                   if($col=="all")
                    $s="select * from appointment";
				else
				    $s="select * from appointment where  $col='$id';";

				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,$s);
				                echo"<center>";
								echo"<bdoy><h1><u> All appointment Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Appointment ID</th>
									<th>Hospital Id</th>
									<th>Appointment Date</th>
									<th>Appointment Time</th>
									<th>Doctor Id </th>
									<th>Service Id </th>
                  <th>Patient Id </th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['appointment_id']."</td>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";
										echo"<td>"
													.$db_field['appointment_date']."</td>";
										echo"<td>"
													.$db_field['appointment_time']."</td>";
										echo"<td>"
													.$db_field['doctor_id']."</td>";
										echo"<td>"
													.$db_field['service_id']."</td>";
                                        echo"<td>"
													.$db_field['patient_id']."</td>";
                                        echo"</tr>";
									}
								echo"</table>";
								echo "<body><input type=button value='Print' onclick=window.print()></body>";
								echo"</center>";
			}
	}     
    
}

$ob=new appointment1();
if(isset($_REQUEST["b1"]))
  $ob->Save();
if(isset($_REQUEST["b2"]))
	$ob->update();
if(isset($_REQUEST["b3"]))
  $ob->Delete();
if(isset($_REQUEST["b4"]))
	$ob->Allsearch();
if(isset($_REQUEST["b5"]))
	$ob->psearch();
if(isset($_REQUEST["bpsearch"]))
	$ob->specialsearch();
?>