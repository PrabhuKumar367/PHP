<?php
include 'connect.php';
class message extends connect
{
	public function __construct()
	{
		parent::__construct();
	}
	public function save()
	{
	 if($this->db_found==true)
	 {
	   $s="insert into message values('$_POST[t1]','$_POST[t2]','$_POST[t3]','$_POST[t4]')";
	   mysqli_query($this->db_found,$s);
	   echo "Your Meassage is send";
	 }
	 else
		echo "Cheaqe your information";
	}
}
$ob=new message();
if(isset($_REQUEST["b1"]))
	$ob->save();
?>