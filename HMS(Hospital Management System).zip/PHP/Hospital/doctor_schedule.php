<?php
include 'connect.php';
class doctor_shedule extends connect
{
  public function __construct()
  {
    parent::__construct();
  }
  public function Save()
  {
     if($this->db_found==true)
      
      {   	   
				$f=0;
				$r=mysqli_query($this->db_found,"select* from doctor");			                
				 while	($db_field=mysqli_fetch_assoc($r))
				 {
					  if($db_field['doctor_id']==$_POST['t1'])
					  { 
							 $f=1;
							 break;	 
					  }
				 }
				if($f==1)
        { 
       
            $sql="insert into doctor_schedule values('$_POST[t1]','$_POST[t2]','$_POST[t3]','$_POST[t4]','$_POST[t5]')";
            mysqli_query($this->db_found,$sql);
            echo "<script> alert('Record Saved')</script>"; 
        } 
				else
				{

					echo"<script>alert('Doctor id does not match')</script>";
				}
							   			  
			}
     else
        echo "<script> alert ('Database Not Found')</script>";
    }

  public function Delete()
  {
     if($this->db_found==true)
     {
      $sql="delete from doctor_schedule where(doctor_id='$_POST[t1]')";
       mysqli_query($this->db_found,$sql);
       echo "<script> alert('Record Deleted')</script>";
      }
     else
        echo "<script> alert ('Database Not Found')</script>";
    }

    public function update()
    {
      if($this->db_found)
        {
          $sql="update doctor_schedule set start_date='$_POST[t2]',end_date='$_POST[t3]',start_time='$_POST[t4]',end_time='$_POST[t5]' where doctor_id='$_POST[t1]'";
          mysqli_query($this->db_found,$sql);
          echo"<script>alert('Record update...')</script>";
        }
      else
            echo"<script>alert('database not found....')</script>";
    }

  public function allsearch()
    {
      if($this->db_found)
        {
          $r=mysqli_query($this->db_found,"select* from doctor_schedule order by doctor_id;");
                          echo"<center>";
                  echo"<bdoy><h1><u> Doctor Schedule </u></h1>";
                  echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
                  echo"<tr bgcolor=cray>";
                  echo"<th>Doctor ID</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Start Time</th>
                    <th>End Time</th>";
                  echo"</tr>";
                  while	($db_field=mysqli_fetch_assoc($r))
                    {
                          echo"<tr>";
                      echo"<td>"
                            .$db_field['doctor_id']."</td>";
                      echo"<td>"
                            .$db_field['start_date']."</td>";
                      echo"<td>"
                            .$db_field['end_date']."</td>";
                      echo"<td>"
                            .$db_field['start_time']."</td>";
                      echo"<td>"
                            .$db_field['end_time']."</td>";
                                          echo"</tr>";
                    }
                  echo"</table>";
                  echo"</center>";
        }
    }

  public function Psearch()
    {
      if($this->db_found)
        {
          $id=$_POST["t1"];
				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,"select * from doctor_schedule where  doctor_id='$id';");
                  echo"<center>";
                  echo"<bdoy><h1><u> Doctor Schedule </u></h1>";
                  echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
                  echo"<tr bgcolor=cray>";
                  echo"<th>Doctor ID</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Start Time</th>
                    <th>End Time</th>";
                  echo"</tr>";
                  while	($db_field=mysqli_fetch_assoc($r))
                    {
                          echo"<tr>";
                      echo"<td>"
                            .$db_field['doctor_id']."</td>";
                      echo"<td>"
                            .$db_field['start_date']."</td>";
                      echo"<td>"
                            .$db_field['end_date']."</td>";
                      echo"<td>"
                            .$db_field['start_time']."</td>";
                      echo"<td>"
                            .$db_field['end_time']."</td>";
                                          echo"</tr>";
                    }
                  echo"</table>";
                  echo"</center>";
        }
    }


    public function specialsearch()
    {
      if($this->db_found)
        {
          $id=$_POST["t1"];
				  $col=$_POST["s1"];
          if($col=="all")
                    $s="select * from doctor_schedule ";
				  else
				    $s="select * from  doctor_schedule where  $col='$id';";
				    $r=mysqli_query($this->db_found,$s);
                  echo"<center>";
                  echo"<bdoy><h1><u> Doctor Schedule </u></h1>";
                  echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
                  echo"<tr bgcolor=cray>";
                  echo"<th>Doctor ID</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Start Time</th>
                    <th>End Time</th>";
                  echo"</tr>";
                  while	($db_field=mysqli_fetch_assoc($r))
                    {
                          echo"<tr>";
                      echo"<td>"
                            .$db_field['doctor_id']."</td>";
                      echo"<td>"
                            .$db_field['start_date']."</td>";
                      echo"<td>"
                            .$db_field['end_date']."</td>";
                      echo"<td>"
                            .$db_field['start_time']."</td>";
                      echo"<td>"
                            .$db_field['end_time']."</td>";
                                          echo"</tr>";
                    }
                  echo"</table>";
                  echo"</center>";
        }
    }
  }

$ob=new doctor_shedule();
if(isset($_REQUEST["b1"]))
  $ob->Save();
if(isset($_REQUEST["b2"]))
	$ob->update();
if(isset($_REQUEST["b3"]))
  $ob->Delete();
if(isset($_REQUEST["b4"]))
	$ob->allsearch();
if(isset($_REQUEST["b5"]))
	$ob->psearch();
if(isset($_REQUEST["bpsearch"]))
	$ob->specialsearch();
?>