<?php
include 'connect.php';
class hospital extends connect
{
  public function __construct()
  {
    parent::__construct();
  }
  public function Save()
  {
     if($this->db_found==true)
	  {	   
		$f=0;
		$r=mysqli_query($this->db_found,"select* from Hospital");			                
		 while	($db_field=mysqli_fetch_assoc($r))
		 {
			  if($db_field['hospital_id']==$_POST['t1'])
			  { 
					 $f=1;
					 break;	 
			  }
		 }
		if($f==1)
		  echo "<script>alert('Hospital ID already exist')</script>";
		else
		{
			$sql="insert into Hospital values('$_POST[t1]','$_POST[t2]','$_POST[t3]','$_POST[t4]','$_POST[t5]','$_POST[t6]')";
			mysqli_query($this->db_found,$sql);
			echo "<script> alert('Record Saved')</script>";
		   }				  	          
    }
     else
        echo "<script> alert ('Database Not Found')</script>";
    }
  
  public function Delete()
  {
     if($this->db_found==true)
     {
      $sql="delete from hospital where(hospital_id='$_POST[t1]')";
       mysqli_query($this->db_found,$sql);
       echo "<script> alert('Record Deleted')</script>";
      }
     else
        echo "<script> alert ('Database Not Found')</script>";
  }

  public function update()
	{
		if($this->db_found)
			{
				$sql="update hospital set hospital_name='$_POST[t2]',contact_number='$_POST[t3]',e_mail='$_POST[t4]',contact_person='$_POST[t5]',region='$_POST[t6]' where hospital_id='$_POST[t1]'";
				mysqli_query($this->db_found,$sql);
				echo"<script>alert('Record update...')</script>";
			}
		else
			    echo"<script>alert('database not found....')</script>";
	}

  public function Allsearch()
	{
		if($this->db_found)
			{
				$r=mysqli_query($this->db_found,"select* from hospital order by hospital_id;");
				                echo"<center>";
								echo"<bdoy><h1><u> All Doctor Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Hospital Id</th>
									<th>Hospital Name</th>
									<th>Contact Number</th>
									<th>Email</th>
									<th>Contact Person</th>
									<th>Region</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";
										echo"<td>"
													.$db_field['hospital_name']."</td>";
										echo"<td>"
													.$db_field['contact_number']."</td>";
										echo"<td>"
													.$db_field['e_mail']."</td>";
										echo"<td>"
													.$db_field['contact_person']."</td>";
										echo"<td>"
													.$db_field['region']."</td>";
                                        echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
	}

  public function Psearch()
	{
		if($this->db_found)
			{
				$id=$_POST["t1"];
				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,"select * from hospital where  hospital_id='$id';");
				        echo"<center>";
								echo"<bdoy><h1><u> All Doctor Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Hospital Id</th>
									<th>Hospital Name</th>
									<th>Contact Number</th>
									<th>Email</th>
									<th>Contact Person</th>
									<th>Region</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";
										echo"<td>"
													.$db_field['hospital_name']."</td>";
										echo"<td>"
													.$db_field['contact_number']."</td>";
										echo"<td>"
													.$db_field['e_mail']."</td>";
										echo"<td>"
													.$db_field['contact_person']."</td>";
										echo"<td>"
													.$db_field['region']."</td>";
                                        echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
	}


	public function specialsearch()
	{
		if($this->db_found)
			{
				$id=$_POST["t1"];
				$col=$_POST["s1"];
                   if($col=="all")
                    $s="select * from hospital";
				else
				    $s="select * from hospital where  $col='$id';";

				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,$s);
				        echo"<center>";
								echo"<bdoy><h1><u> All Hospital Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Hospital Id</th>
									<th>Hospital Name</th>
									<th>Contact Number</th>
									<th>Email</th>
									<th>Contact Person</th>
									<th>Region</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";
										echo"<td>"
													.$db_field['hospital_name']."</td>";
										echo"<td>"
													.$db_field['contact_number']."</td>";
										echo"<td>"
													.$db_field['e_mail']."</td>";
										echo"<td>"
													.$db_field['contact_person']."</td>";
										echo"<td>"
													.$db_field['region']."</td>";
                                        echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
	}

	public function specialupdate()
    {
      if($this->db_found==true)
      {
        $f=$_POST['t1'];
        $s=$_POST['s1'];
        $m="select * from  hospital where $s='$f'";
        $r=mysqli_query($this->db_found,$m);
        echo "<table border=2 bgcolor=pink><tr><th>Patient id</th><th>Patient name</th><th>Gender</th><th>Nationality</th><th>Birth date</th><th>Conatct no</th><th>Blood group</th></tr>"; 
        while($db_field=mysqli_fetch_assoc($r))
        {
          echo "<form name=f method=post action=hospital.php>";
          echo "<tr><th><input type=text value=".$db_field['patient_id']."  name=t1 readonly></th>";
          echo "<th><input type=text value=".$db_field['patient_name']." name=t2></th>";
          echo "<th><input type=text value=".$db_field['gender']." name=t3></th>";
          echo "<th><input type=text value=".$db_field['nationality']." name=t4></th>";
          echo "<th><input type=text value=".$db_field['birth_date']." name=t5></th>";
          echo "<th><input type=text value=".$db_field['contact_no']." name=t6></th>";
          echo "<th><input type=text value=".$db_field['blood_group']." name=t7></th>";
          echo "<th><input type=submit value=Update name=b4></th></tr>";
        }
      }
    }
}

$ob=new hospital();
if(isset($_REQUEST["b1"]))
	$ob->save();
if(isset($_REQUEST["b2"]))
	$ob->update();
if(isset($_REQUEST["b3"]))
	$ob->delete();
if(isset($_REQUEST["b4"]))
	$ob->Allsearch();
if(isset($_REQUEST["b5"]))
	$ob->psearch();
if(isset($_REQUEST["bpsearch"]))
	$ob->specialsearch();
if(isset($_REQUEST["bpupdate"]))
	$ob->specialupdate();
?>