<?php
include 'connect.php';
class Book_appointment extends connect
{
	public function __construct()
	{
		parent::__construct();
	}
	public function Appointment()
	{
		if($this -> db_found ==true)
		{
			$f=0;
                if($f==0)
                {
                    $sql = "insert into Book_Appointment values('$_POST[t1]','$_POST[t2]','$_POST[t3]','$_POST[t4]','$_POST[t5]','$_POST[t6]','$_POST[t7]')";
                    mysqli_query($this -> db_found, $sql);
                    echo"<script> alert ('Appointment Booked') </script>";
                }
                else 
				 echo"<script> alert ('Information is wrong') </script>";
						
		}
		else
			echo"<script> alert ('Database Not Found') </script>";
	}
}
$ob=new Book_Appointment();
if(isset($_REQUEST["b1"]))
	$ob->Appointment();
?>