<?php
include 'connect.php';
class staff extends connect
{
  public function __construct()
  {
    parent::__construct();
  }
  public function Save()
  {
     if($this->db_found==true)
	  {
	   
	   
		$f=0;
		$r=mysqli_query($this->db_found,"select* from staff");			                
		 while	($db_field=mysqli_fetch_assoc($r))
		 {
			  if($db_field['staff_id']==$_POST['t1'])
			  { 
					 $f=1;
					 break;	 
			  }
		 }

		 $r=mysqli_query($this->db_found,"select* from staff");
		 $h=0;
		 while	($db_field=mysqli_fetch_assoc($r))
		 {
			  if($db_field["hospital_id"]==$_POST["t6"])
			  { 
				 $h=1;//hospital id match
				 break;
			  }
		 }
		 if($f==0 && $h==1)
		 {
			$sql="insert into staff values('$_POST[t1]','$_POST[t2]','$_POST[t3]','$_POST[t4]','$_POST[t5]','$_POST[t6]')";
			mysqli_query($this->db_found,$sql);
			echo "<script> alert('Record Saved')</script>";
		}	
	  
		else if($f==1)
			echo"<script> alert ('Doctor id already exist') </script>";
		else if($h==0)
			echo"<script> alert ('Hospital id not present') </script>";
      }
	 else
			echo "<script> alert ('Database Not Found')</script>";
 }

  public function Delete()
  {
     if($this->db_found==true)
     {
       $sql="delete from staff where(staff_id='$_POST[t1]')";
       mysqli_query($this->db_found,$sql);
       echo "<script> alert('Record Deleted')</script>";
      }
     else
        echo "<script> alert ('Database Not Found')</script>";
  }

  public function update()
	{
		if($this->db_found)
			{
				$sql="update staff set staff_name='$_POST[t2]',designation='$_POST[t3]',contact_number='$_POST[t4]',e_mail='$_POST[t5]',hospital_id='$_POST[t6]' where staff_id='$_POST[t1]'";
				mysqli_query($this->db_found,$sql);
				echo"<script>alert('Record update...')</script>";
			}
		else
			    echo"<script>alert('database not found....')</script>";
	}

  public function allsearch()
	{
		if($this->db_found)
			{
				$r=mysqli_query($this->db_found,"select* from staff order by staff_id;");
				                echo"<center>";
								echo"<bdoy><h1><u> Staff Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Staff ID</th>
									<th>Staff Name</th>
									<th>Designation</th>
									<th>Contact Number</th>
									<th>E_mail</th>
									<th>Hospital id</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['staff_id']."</td>";
										echo"<td>"
													.$db_field['staff_name']."</td>";
										echo"<td>"
													.$db_field['designation']."</td>";
										echo"<td>"
													.$db_field['contact_number']."</td>";
										echo"<td>"
													.$db_field['e_mail']."</td>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";
                                        echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
	}

  public function psearch()
	{
		if($this->db_found)
			{
				$id=$_POST["t1"];
				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,"select * from staff where  staff_id='$id';");
				        echo"<center>";
								echo"<bdoy><h1><u> Staff Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Staff ID</th>
									<th>Staff Name</th>
									<th>Designation</th>
									<th>Contact Number</th>
									<th>E_mail</th>
									<th>Hospital id</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['staff_id']."</td>";
										echo"<td>"
													.$db_field['staff_name']."</td>";
										echo"<td>"
													.$db_field['designation']."</td>";
										echo"<td>"
													.$db_field['contact_number']."</td>";
										echo"<td>"
													.$db_field['e_mail']."</td>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";
                    echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
	}



	public function specialsearch()
	{
		if($this->db_found)
			{
				$id=$_POST["t1"];
				$col=$_POST["s1"];
                   if($col=="all")
                    $s="select * from staff";
				else
				    $s="select * from staff where  $col='$id';";

				//echo "select * from doctor where  doctor_id='$id';";
				$r=mysqli_query($this->db_found,$s);
				        echo"<center>";
								echo"<bdoy><h1><u> Staff Detail </u></h1>";
								echo"<table border=1 bgcolor=#e3dedc cellpadding=10 cellspacing=0>";
								echo"<tr bgcolor=cray>";
								echo"<th>Staff ID</th>
									<th>Staff Name</th>
									<th>Designation</th>
									<th>Contact Number</th>
									<th>E_mail</th>
									<th>Hospital id</th>";
								echo"</tr>";
								while	($db_field=mysqli_fetch_assoc($r))
									{
								        echo"<tr>";
										echo"<td>"
													.$db_field['staff_id']."</td>";
										echo"<td>"
													.$db_field['staff_name']."</td>";
										echo"<td>"
													.$db_field['designation']."</td>";
										echo"<td>"
													.$db_field['contact_number']."</td>";
										echo"<td>"
													.$db_field['e_mail']."</td>";
										echo"<td>"
													.$db_field['hospital_id']."</td>";
                    echo"</tr>";
									}
								echo"</table>";
								echo"</center>";
			}
	}
}

$ob=new staff();
if(isset($_REQUEST["b1"]))
  $ob->Save();
if(isset($_REQUEST["b2"]))
	$ob->update();
if(isset($_REQUEST["b3"]))
  $ob->Delete();
if(isset($_REQUEST["b4"]))
	$ob->allsearch();
if(isset($_REQUEST["b5"]))
	$ob->psearch();
if(isset($_REQUEST["bpsearch"]))
	$ob->specialsearch();
?>